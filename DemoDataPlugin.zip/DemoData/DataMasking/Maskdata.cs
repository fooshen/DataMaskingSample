﻿using Microsoft.Xrm.Sdk;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoData.DataMasking
{
    internal class Maskdata: PluginBase
    {
        public Maskdata(string unsecure, string secure): base(typeof(Maskdata))  { }

        protected override void ExecuteCdsPlugin(ILocalPluginContext localContext)
        {
            if (localContext == null)
            {
                throw new InvalidPluginExecutionException(nameof(localContext));
            }
            ITracingService tracingService = localContext.TracingService;

            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)localContext.PluginExecutionContext;
                IOrganizationService service = localContext.CurrentUserService;

                if(context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity entity = (Entity)context.InputParameters["Target"];
                    tracingService.Trace($"Entity name: {entity.LogicalName}");
                    if(entity.LogicalName == "demo_demotransaction")
                    {
                        tracingService.Trace($"Message: {context.MessageName}, Operation: {context.Stage.ToString()}");

                        //for create and update as a pre-operation
                        if (context.MessageName == "Create" || context.MessageName == "Update")
                        {
                            //pre-operation stage
                            if(context.Stage == 20)
                            {
                                if (entity.Attributes.Contains("demo_accountnumber"))
                                {
                                    var accNumber = entity["demo_accountnumber"].ToString();                                   
                                    var maskedValue = "*****";                                    
                                    entity["demo_accountnumber"] = maskedValue;                                                                       

                                    //SAMPLE: Hard-coded encryption key using "TEST". Replace with more secure methods
                                    //careful with performance - retrieval from keyvault
                                    byte[] encrypted = Common.EncryptString(accNumber, "TEST");
                                    var encryptedValue = Convert.ToBase64String(encrypted);                                    
                                    entity.Attributes.Add("demo_accountnumberencrypted", encryptedValue);

                                    tracingService.Trace($"Encrypted: {encrypted}");
                                }
                            }
                        }                        
                    }
                }
                
            }
            catch (Exception ex)
            {
                tracingService?.Trace("An error occurred executing Plugin ExportTable : {0}", ex.ToString());
                throw new InvalidPluginExecutionException("An error occurred executing Plugin ExportTable.", ex);
            }
        }
    }
}
