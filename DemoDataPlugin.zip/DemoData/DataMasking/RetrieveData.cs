﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoData.DataMasking
{
    internal class RetrieveData:PluginBase
    {
        public RetrieveData(string unsecure, string secure) : base(typeof(RetrieveData)) { }

        protected override void ExecuteCdsPlugin(ILocalPluginContext localContext)
        {
            if (localContext == null)
            {
                throw new InvalidPluginExecutionException(nameof(localContext));
            }
            ITracingService tracingService = localContext.TracingService;

            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)localContext.PluginExecutionContext;
                IOrganizationService service = localContext.CurrentUserService;
                tracingService.Trace($"Message: {context.MessageName}, Operation: {context.Stage.ToString()}");

                if(context.MessageName == "Retrieve" && context.Stage == 40 )
                {
                    if (context.OutputParameters.Contains("BusinessEntity") && context.OutputParameters["BusinessEntity"] is Entity)
                    {
                        Entity entity = (Entity)context.OutputParameters["BusinessEntity"];
                        tracingService.Trace($"Entity name: {entity.LogicalName}");
                        if (entity.LogicalName == "demo_demotransaction")
                        {
                            //for retrieve
                            if (context.MessageName == "Retrieve" && context.Stage == 40)
                            {
                                var encrypted = entity["demo_accountnumberencrypted"].ToString();
                                tracingService.Trace($"Value: {encrypted}");
                                byte[] encryptedValue = Convert.FromBase64String(encrypted);
                                var decryptedValue = Common.DecryptString(encryptedValue, "TEST");
                                entity.Attributes["demo_accountnumberencrypted"] = decryptedValue;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService?.Trace("An error occurred executing Plugin ExportTable : {0}", ex.ToString());
                throw new InvalidPluginExecutionException("An error occurred executing Plugin ExportTable.", ex);
            }
        }
    }
}
