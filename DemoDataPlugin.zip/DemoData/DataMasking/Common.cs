﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DemoData.DataMasking
{
    internal static class Common
    {
        internal static byte[] EncryptString(string plainText, string key)
        {
            byte[] keyBytes = GetKeyBytes(key);
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);

            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = keyBytes;
                aesAlg.Mode = CipherMode.ECB; // ECB mode for simplicity, use a more secure mode in practice
                aesAlg.Padding = PaddingMode.PKCS7; // PKCS7 padding is commonly used
                using (ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV))
                {
                    return encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
                }
            }
        }

        internal static string DecryptString(byte[] cipherText, string key)
        {
            byte[] keyBytes = GetKeyBytes(key);

            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = keyBytes;
                aesAlg.Mode = CipherMode.ECB; // ECB mode for simplicity, use a more secure mode in practice
                aesAlg.Padding = PaddingMode.PKCS7; // PKCS7 padding is commonly used
                using (ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV))
                {
                    byte[] decryptedBytes = decryptor.TransformFinalBlock(cipherText, 0, cipherText.Length);
                    return Encoding.UTF8.GetString(decryptedBytes);
                }
            }
        }
        private static byte[] GetKeyBytes(string key)
        {
            // Use SHA256 to derive a valid AES key of appropriate size
            using (SHA256 sha256 = SHA256.Create())
            {
                return sha256.ComputeHash(Encoding.UTF8.GetBytes(key));
            }
        }

    }
}
